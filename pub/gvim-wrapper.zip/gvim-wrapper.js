/*!
 * gvim-wrapper.js
 * Append "-p --remote-tab-silent" option and run gVim
 *
 * Copyright (c) 2009 Kyo Nagashima <kyo@hail2u.net>
 * This library licensed under MIT license:
 * http://opensource.org/licenses/mit-license.php
 */
var command = "C:\\vim\\gvim.exe -p --remote-tab-silent";

var args = WScript.Arguments;

for (var i = 0; i < args.length; i++) {
  var arg = args(i);

  if (arg !== "-p" && arg !== "--remote-tab-silent") {
    command += " \"" + arg + "\"";
  }
}

var WshShell = WScript.CreateObject("WScript.Shell");
WshShell.Run(command);
