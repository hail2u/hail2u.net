#!/usr/local/bin/perl

use strict;

use HTML::RSSAutodiscovery;
use URI;

my $bookmark = shift;

open (FH, "< $bookmark") || die "file open error.\n";
my @file = <FH>;
close(FH);

my @urls;

foreach my $line (@file) {
	if ($line =~ /HREF="(.*?)"/i) {
		push(@urls, $1);
	}
}

my @rssurls;

foreach my $url (@urls) {
	my $parser = HTML::RSSAutodiscovery->new();
	my $result = $parser->parse($url);

	foreach (@$result) {
		my $rssurl = URI->new_abs($_->{'href'}, $url);
		push(@rssurls, $rssurl);
	}
}

print join("\n", @rssurls);
print "\n";

exit;
