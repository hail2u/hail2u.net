#!/usr/local/bin/perl

use strict;

use HTTP::Date;
use LWP::Simple;

# �f�B���N�g����؂蕶���܂�
my $dir = "E:\\Documents\\BlogRolling\\";

# see http://www.blogrolling.com/members.phtml
# and goto "Get Code"
my $id = 'd7a5de21cd06d20958953d1eaafa006e';

my $content = LWP::Simple::get("http://rpc.blogrolling.com/opml.php?r=$id");

if ($content) {
	my @content = split("\n", $content);

	foreach my $line (@content) {

		if ($line =~ m!^<outline text="(.*?)" type="link" url="(.*?)" lastmod="Last updated: (.*?)" target=.*/>$!) {
			my($name, $url, $lmod) = ($1, $2, $3);
			$name = &escape_name($name);
			$lmod = &convert2time($lmod);
			# time - ���{�Ƃ̎��� - 6����
			# 6���Ԃ𒲐߂��ĐV���Ƃ݂Ȃ����Ԃ𒲐�
			my $now = time - 32400 - 21600;

			if ($lmod > $now) {
				&create_lnk($name, $url, 1);
			}
			else {
				&create_lnk($name, $url, 0);
			}
		}
		elsif ($line =~ m!^<outline text="(.*?)" type="link" url="(.*?)".*/>$!) {
			my($name, $url) = ($1, $2);
			$name = &escape_name($name);
			&create_lnk($name, $url, 0);
		}
	}
}

exit;

sub escape_name {
	my $str = $_[0];

	$str =~ s!\\!��!g;
	$str =~ s!/!�^!g;
	$str =~ s!:!�F!g;
	$str =~ s!,!�C!g;
	$str =~ s!;!�G!g;
	$str =~ s!\*!��!g;
	$str =~ s!\?!�H!g;
	$str =~ s!"!�h!g;
	$str =~ s!<!��!g;
	$str =~ s!>!��!g;
	$str =~ s!\|!�b!g;

	return $str;
}

sub convert2time {
	my $timestr = $_[0];

	if ($timestr =~ /^(\d*?):(\d*?):(\d*?) (\w.*) on (\w*?), (\w*?) (\d*?)$/) {
		my($mm, $dd, $hh, $nn, $ss, $ww, $tz) = ($6, $7, $1, $2, $3, $5, $4);
		$mm = substr($mm, 0, 3);
		$ww = substr($ww, 0, 3);
		$timestr = "$ww, $dd-$mm-03 $hh:$nn:$ss $tz";
	}

	my $time = HTTP::Date::str2time($timestr);

	return $time;
}

sub create_lnk {
	my($name, $url, $is_new) = @_;
	my @icons = (
		"E:\\Documents\\Icons\\NoUpdate.ico",
		"E:\\Documents\\Icons\\Update.ico",
	);

	open(URLFILE, ">$dir$name.url") or exit;
	print URLFILE <<"_EOF_";
[InternetShortcut]
URL=$url
IconFile=$icons[$is_new]
IconIndex=0
_EOF_
	close(URLFILE);
}
