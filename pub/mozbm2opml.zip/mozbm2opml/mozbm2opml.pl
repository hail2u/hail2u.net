#!/usr/local/bin/perl

use strict;

use Jcode;
use LWP::Simple;
use HTML::RSSAutodiscovery;
use URI;
use XML::RSS;

my $bookmark = shift;

print STDERR "Opening file ... ";

open (FH, "< $bookmark") || die "Error: failed to open.\n\n";
my @file = <FH>;
close(FH);

print STDERR "Done.\n";

my @urls;

print STDERR "Extracting URL ... ";

foreach my $line (@file) {
	if ($line =~ /HREF="(.*?)"/i) {
		push(@urls, $1);
	}
}

if (!@urls) {
	die "Error.\n\n" ;
}

print STDERR "Done.\n";

my @rssurls;

print STDERR "Checking URLs ...\n";

foreach my $url (@urls) {
	print STDERR "  $url\n";

	my $parser = HTML::RSSAutodiscovery->new();
	my $result = $parser->parse($url);

	next if !$result;

	foreach (@$result) {
		my $rssurl = URI->new_abs($_->{'href'}, $url);
		push(@rssurls, $rssurl);
	}
}

print STDERR "Done.\n";

my @outlines;

print STDERR "Generating outline elements ...\n";

foreach my $rssurl (@rssurls) {
	print STDERR "  $rssurl\n";

	print STDERR "  Getting    ... ";
	my $content = LWP::Simple::get($rssurl);
	if ($content) {
		print STDERR "Done.\n";

		my $j = Jcode->new();
		my $content = $j->set($content)->utf8;
		$content =~ s/<\?xml.*?\?>/<\?xml version="1.0" encoding="UTF-8"\?>/;

		print STDERR "  Parsing    ... ";
		my $rss = XML::RSS->new();
		eval {
			$rss->parse($content);
		};

		if (!$@) {
			print STDERR "Done.\n";

			print STDERR "  Generating ... ";
			my $title = $rss->{'channel'}->{'title'};
			my $url = $rss->{'channel'}->{'link'};
			my $description = $rss->{'channel'}->{'description'};
			push(@outlines, qq!\t\t<outline text="$title" htmlUrl="$url" description="$description" type="rss" xmlUrl="$rssurl" />\n!);
			print STDERR "Done.\n";
		}
		else {
			print STDERR "Error.\n";
		}
	}
	else {
		print STDERR "Error.\n";
	}
}

print STDERR "Done.\n";

(my $dateCreated = gmtime) =~ s/^(\w+) (\w+) (\d+) (\d\d:\d\d:\d\d) (\d{4})/$1, $3 $2 $5 $4 GMT/;

print STDERR "Outputting OPML ... ";

print <<"_OPML_";
<?xml version="1.0" encoding="UTF-8"?>
<opml version="1.0">
	<head>
		<title>RSS Subscriptions</title>
		<dateCreated>$dateCreated</dateCreated>
	</head>
	<body>
_OPML_

print join("", @outlines);

print <<"_OPML_";
	</body>
</opml>
_OPML_

print STDERR "Done.\n";

print STDERR "Mission Completed.\n\n";

exit;
